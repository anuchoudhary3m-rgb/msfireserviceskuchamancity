# MS FIRE SAFETY — Official Policies & Company Documentation

**Official Website:** [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/)  
**Business Name:** MS Fire Safety (MS FIRE SERVICE INDUSTRIES)  
**Proprietor:** Pro. Manohar Lal Sewda  
**Direct Phone:** +91 6378647799 / 6378647799  
**Official Email:** info@msfiresafetykuchamancity.com  
**Verified Address:** Sikar Road, Kuchaman City, Didwana-Kuchaman / Nagaur District, Rajasthan – 341508, India  
**Google Maps Location:** [https://maps.app.goo.gl/7QGkDBb3kSXk7aSm6](https://maps.app.goo.gl/7QGkDBb3kSXk7aSm6)  
**Effective Date:** October 1, 2026  
**Last Updated:** October 16, 2026  

---

## 1. About Us

### Welcome to MS Fire Safety

MS Fire Safety (MS FIRE SERVICE INDUSTRIES) is a fire safety business serving residential, commercial, educational, and industrial customers in and around **Kuchaman City, Rajasthan, India**. We aim to help customers understand fire protection requirements and find suitable fire safety products and services tailored for their premises.

Our services include ISI-marked fire extinguisher supply and refilling, fire hydrant systems, automatic sprinkler systems, fire alarm installations, and comprehensive fire protection solutions, subject to the services actually offered by our business.

### Our Mission

Our mission is to support fire safety awareness and help customers make informed, life-saving decisions about fire prevention and protection. We believe that appropriate equipment, proper installation, regular inspection, and responsible maintenance are important parts of an effective fire safety plan.

### Our Services

Depending on the project and service requirements, our offerings include:

- **Fire extinguisher supply and refilling:** ISI certified ABC Dry Powder, CO2 gas cylinders, Mechanical Foam (AFFF), Clean Agent, and Water type fire extinguishers with doorstep refill & hydraulic pressure testing.
- **Fire hydrant system installation:** Underground and above-ground pipeline networks, landing valves, hose reels, fire brigade inlets, and pumping systems.
- **Automatic sprinkler system installation:** Thermal bulb automatic sprinkler networks, alarm check valves, and water supply integration.
- **Fire protection equipment and accessories:** Fire blankets, hose boxes, emergency signage, smoke alarms, and safety gear.
- **Fire safety consultation and maintenance:** Annual maintenance contracts (AMC), periodic inspections, and safety guidance.

Please contact us to confirm service availability, product specifications, pricing, and project requirements.

### Our Approach

We aim to communicate clearly with customers, understand their requirements, and provide relevant information about available fire safety solutions. Product selection and system design should consider the premises, applicable safety standards (such as IS 2190 & IS 15683), and recommendations from qualified professionals.

### Our Location & Contact

- **Business Name:** MS Fire Safety (MS FIRE SERVICE INDUSTRIES)
- **Proprietor:** Manohar Lal Sewda (Pro. Manohar Lal)
- **Location:** Kuchaman City, Rajasthan, India
- **Full Business Address:** Sikar Road, Kuchaman City, Didwana-Kuchaman District, Rajasthan – 341508, India
- **Phone:** +91 6378647799 / 6378647799
- **Email:** info@msfiresafetykuchamancity.com
- **Website:** [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/)

---

## 2. Privacy Policy

**Effective Date:** October 1, 2026  
**Last Updated:** October 16, 2026  

### 1. Introduction

Welcome to MS Fire Safety ("we", "our", or "us", also operating as MS FIRE SERVICE INDUSTRIES). This Privacy Policy explains how information may be collected, used, stored, and disclosed when you visit [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/) ("Website").

We are committed to handling personal information responsibly and explaining our privacy practices clearly in accordance with applicable Indian privacy standards and digital regulations.

- **Business Contact:** info@msfiresafetykuchamancity.com
- **Business Address:** Sikar Road, Kuchaman City, Didwana-Kuchaman District, Rajasthan – 341508, India
- **Phone:** +91 6378647799

### 2. Information We May Collect

Depending on how you use our Website, we may collect the following categories of information:

- **Contact information:** Name, email address, phone number, and other information you voluntarily submit through a contact form, WhatsApp enquiry, or phone call.
- **Enquiry information:** Details about products, refilling services, quotations, or projects you ask us about.
- **Technical information:** Browser type, device information, IP address, approximate location, and website usage data collected by hosting servers.
- **Cookies and similar technologies:** Information used to support website functionality, measure traffic, remember preferences, or provide advertising where applicable.

*Please do not submit sensitive personal information through general enquiry forms.*

### 3. How We Use Information

We may use collected information, as applicable, to:

- Respond to customer enquiries, service requests, and refilling pickups.
- Provide accurate quotations and technical product information.
- Maintain, secure, and improve Website performance.
- Understand aggregate website traffic and usage trends.
- Prevent fraud, spam, and misuse.
- Meet applicable legal obligations under Indian law.
- Support analytics and advertising services where enabled.

We will use personal information solely for purposes consistent with the reason it was collected.

### 4. Cookies and Similar Technologies

Our Website or third-party services may use cookies or similar technologies to maintain functionality, analyse website traffic, remember user preferences, or support advertising.

You can manage or disable cookies through your browser settings. Disabling cookies may affect certain website features.

### 5. Google AdSense and Third-Party Advertising

Our Website may use Google AdSense or other third-party advertising services now or in the future.

When Google advertising is enabled, Google and its partners may use cookies (such as DoubleClick cookies) or similar technologies to serve advertisements based on a user's prior visits to this Website or other websites on the Internet, measure advertising performance, and personalise ads where permitted.

Users can learn more about Google's advertising practices and controls here:

- **Google Privacy Policy:** [https://policies.google.com/privacy](https://policies.google.com/privacy)
- **How Google uses information from sites or apps that use its services:** [https://policies.google.com/technologies/partner-sites](https://policies.google.com/technologies/partner-sites)
- **Google Ads Settings:** [https://adssettings.google.com/](https://adssettings.google.com/)
- **Network Advertising Initiative (NAI):** [https://optout.networkadvertising.org/](https://optout.networkadvertising.org/)

Users can manage their ad personalisation preferences or opt out of personalized ads via Google Ads Settings.

### 6. Third-Party Services

The Website uses verified third-party providers for hosting, mapping, and font delivery:

- **Hosting & CDN:** GitHub Pages & Cloudflare CDN
- **Mapping & Location:** Google Maps
- **Web Fonts & Icons:** Google Fonts & Font Awesome CDN
- **Direct Messaging:** WhatsApp Web API (click-to-chat)

These providers process information under their own privacy policies.

### 7. Sharing of Information

We do not sell, rent, or trade personal information to third parties as a standalone commercial database.

We may share information with authorized personnel or technicians who help fulfill requested services, when legally required, or to protect security and rights under Indian law.

### 8. Data Retention and Security

We retain personal information only for as long as reasonably necessary to fulfill customer enquiries, service contracts, or statutory obligations.

We take reasonable technical and administrative precautions to protect information against unauthorised access, alteration, disclosure, or destruction.

### 9. Your Privacy Rights

Depending on applicable law (including India's Digital Personal Data Protection Act), you have rights to request access to, correction of, or deletion of your personal data.

To submit a privacy-related request, contact:
- **Email:** info@msfiresafetykuchamancity.com
- **Postal:** MS Fire Safety, Sikar Road, Kuchaman City, Rajasthan 341508, India

### 10. Children's Privacy

Our Website is not directed to children under 18 years of age. If you believe a child has submitted personal information, please contact us for immediate removal.

### 11. External Links

Our Website may contain links to third-party websites. We are not responsible for the privacy practices, content, or security of external websites.

### 12. Changes to This Privacy Policy

We may update this Policy to reflect operational, technological, or legal modifications. The revised version will be published on this page with an updated date.

### 13. Contact Us

For questions or requests regarding this Privacy Policy:
- **Business Name:** MS Fire Safety (MS FIRE SERVICE INDUSTRIES)
- **Email:** info@msfiresafetykuchamancity.com
- **Phone:** +91 6378647799 / 6378647799
- **Address:** Sikar Road, Kuchaman City, Rajasthan 341508, India
- **Website:** [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/)

---

## 3. Contact Us

### Get in Touch with MS Fire Safety

Do you have questions about fire extinguishers, refilling services, fire hydrant systems, automatic sprinkler systems, or other fire protection requirements?

Contact MS Fire Safety to discuss your requirements. We will review your enquiry and respond promptly.

### Business Information

- **Business Name:** MS Fire Safety (MS FIRE SERVICE INDUSTRIES)
- **Proprietor / Contact Person:** Manohar Lal Sewda (Pro. Manohar Lal)
- **Location:** Kuchaman City, Rajasthan, India
- **Full Address:** Sikar Road, Kuchaman City, Didwana-Kuchaman District, Rajasthan – 341508, India
- **Phone Number:** +91 6378647799 / 6378647799
- **Email Address:** info@msfiresafetykuchamancity.com
- **Business Hours:** Monday to Sunday: 8:00 AM – 8:00 PM (Emergency 24/7 Response Available)
- **Website:** [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/)

### Our Services

For enquiries about the following services, please contact us to confirm availability:

- Fire extinguisher supply and refilling (ABC, CO2, Foam, Water)
- Fire hydrant systems and piping installations
- Automatic sprinkler systems
- Smoke detectors, sirens, and fire alarm systems
- Annual Maintenance Contracts (AMC)
- Project-specific fire safety equipment and accessories

### Send Us an Enquiry

Please provide the following details when contacting us:

- **Your Name:** Manohar Lal Sewda (or your name/business name)
- **Phone Number / Email:** 6378647799 / info@msfiresafetykuchamancity.com
- **Service or Product Enquired About:** Extinguisher Refilling / New Cylinders / Hydrant / Sprinkler
- **Brief Description of Requirements:** Number of cylinders, building type, or questions

**Direct Helpline & WhatsApp:** 6378647799  
**Google Maps Location:** [https://maps.app.goo.gl/7QGkDBb3kSXk7aSm6](https://maps.app.goo.gl/7QGkDBb3kSXk7aSm6)

*For urgent fire or life-safety emergencies, dial 101 or 112 immediately.*

---

## 4. Terms and Conditions

**Effective Date:** October 1, 2026  
**Last Updated:** October 16, 2026  

### 1. Introduction

These Terms and Conditions govern your access to and use of [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/) ("Website").

The Website is associated with MS Fire Safety (MS FIRE SERVICE INDUSTRIES), located in Kuchaman City, Rajasthan, India.

By accessing or using this Website, you agree to these Terms. If you do not agree, please discontinue use of the Website.

### 2. Website Information

The Website provides general information about fire safety products, services, installations, and related enquiries. Specific products, services, prices, and availability must be confirmed directly with us.

### 3. Products and Services

Any description of fire extinguishers, refilling, hydrant systems, sprinkler installations, or other services is subject to actual inventory and project requirements. A quotation or order is subject to separate terms agreed upon with the customer. No purchase contract is created solely by viewing information on this Website.

### 4. Pricing and Quotations

Prices, quotations, delivery charges, installation costs, and other commercial terms must be confirmed directly with MS Fire Safety. Information displayed on the Website should not be treated as a binding quotation or guaranteed offer unless confirmed in writing.

### 5. Accuracy of Information

We aim to keep Website information accurate and current. However, product specifications, availability, and service descriptions may change. You should verify technical details before making purchase or project decisions.

### 6. Fire Safety and Professional Advice

Website content is provided for general information and is not a substitute for a site-specific fire risk assessment, engineering design, professional inspection, or advice from qualified fire safety professionals. Equipment selection and installation should follow applicable laws, Indian standards (IS 2190 & IS 15683), and manufacturer instructions.

### 7. Intellectual Property

Unless otherwise indicated, Website text, graphics, branding, and original materials are protected by applicable intellectual property laws. You may view and use content for personal, informational purposes only.

### 8. Acceptable Use

You agree not to use the Website for unlawful purposes, attempt unauthorized access, upload malicious code, or submit false enquiries.

### 9. Third-Party Links

Links to external websites are provided for convenience. We do not control or endorse third-party content.

### 10. Limitation of Liability

To the extent permitted by applicable Indian law, MS Fire Safety shall not be liable for losses arising from reliance on general Website information, temporary Website unavailability, or third-party content.

### 11. Privacy

Your use of the Website is also subject to our Privacy Policy.

### 12. Changes to These Terms

We may revise these Terms as our services or legal obligations change. Updated Terms will be published on this page.

### 13. Governing Law

These Terms are subject to the laws of India. Any dispute will be handled by the competent courts having jurisdiction in Kuchaman City / Didwana / Nagaur, Rajasthan.

### 14. Contact Information

- **Business Name:** MS Fire Safety (MS FIRE SERVICE INDUSTRIES)
- **Proprietor:** Manohar Lal Sewda
- **Email:** info@msfiresafetykuchamancity.com
- **Phone:** +91 6378647799 / 6378647799
- **Address:** Sikar Road, Kuchaman City, Rajasthan 341508, India
- **Website:** [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/)

---

## 5. Disclaimer

**Last Updated:** October 16, 2026  

### General Information

The information provided on [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/) is for general informational and educational purposes relating to fire safety products, equipment, systems, and services. MS Fire Safety makes reasonable efforts to provide accurate information but does not guarantee that all information is complete, accurate, or current at all times.

### Not a Substitute for Professional Advice

Website content is not a substitute for professional fire risk assessments, engineering advice, building-code compliance reviews, or site-specific safety recommendations. Consult qualified fire safety professionals and relevant authorities before making technical or safety decisions.

### Product and Service Information

Descriptions of fire extinguishers, refilling, hydrant systems, sprinkler installations, and other services are provided for general guidance. Specifications, prices, and availability must be confirmed directly with MS Fire Safety.

### Safety Warning

Fire protection equipment must be selected, installed, inspected, tested, and maintained appropriately. Incorrect equipment selection may result in inadequate protection. Never rely solely on Website content to respond to an active fire emergency. Dial 101 or 112 for local emergency services.

### Compliance and Certification

Any reference to standards (IS 15683, IS 2190, NBC), approvals, or certifications must be checked against official documents and actual products or services. The presence of information on this Website does not establish that a building or project has received a particular regulatory approval or fire NOC.

### External Links

This Website may contain links to third-party websites. MS Fire Safety does not control or guarantee external website content or availability.

### Testimonials and Business Claims

Testimonials, feedback, and project highlights displayed on this Website are supported by genuine business records. Results and experiences may vary.

### Limitation of Liability

To the extent permitted by applicable law, MS Fire Safety disclaims liability arising from reliance on general Website information without professional on-site assessment.

### Contact Information

- **Business Name:** MS Fire Safety (MS FIRE SERVICE INDUSTRIES)
- **Proprietor:** Manohar Lal Sewda
- **Email:** info@msfiresafetykuchamancity.com
- **Phone:** 6378647799 / +91 6378647799
- **Address:** Sikar Road, Kuchaman City, Rajasthan (341508), India
- **Website:** [https://www.msfiresafetykuchamancity.com/](https://www.msfiresafetykuchamancity.com/)
